# Meme Generator in React

#### _Throwback to the prework!_

We can use this app as a baseline for exploring testing React applications with Jest and Enzyme.

## Instructions

1.  Clone the repo
1.  `npm i` inside the repo
1.  `npm start` inside the repo to run webpack on port 3000.
