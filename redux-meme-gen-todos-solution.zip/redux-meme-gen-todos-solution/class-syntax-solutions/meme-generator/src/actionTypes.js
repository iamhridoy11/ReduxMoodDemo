export const ADD_MEME = "ADD_MEME"
export const REMOVE_MEME = "REMOVE_MEME"